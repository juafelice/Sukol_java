public class LinkedList
{
    private Node head;
    private Node last;
    private Node current;

    LinkedList()
    {
        head = null;
        last = null;
        current = null;
    }

    //add First
    public void addFirst(Student s)
    {
        Node newNode = new Node(s);
        if (head == null)
        {
            head = newNode;
            last = head;
        }
        else
        {
            newNode.next = head;
            head = newNode;
        }
    }

    //add Last
    public void addLast(Student s)
    {
        Node newNode = new Node(s);
        if(head == null)
        {
            head = newNode;
            last = head;
        }
        else
        {
            last.next = newNode;
            last = newNode;
        }
    }

    //remove First
    public Student removeFirst()
    {
        Student remove = null;

        if(head == null)
        {
            remove = null;
        }
        else
        {
            remove = head.data;
            if(head.next==null)
                head = last = null;
            else
            {
                head = head.next;
            }
        }
        return remove;
    }

    //remove Last
    public Student removeLast()
    {
        Student remove = null;
        Node curr = head;
        Node previous = null;
        if(head == null)
        {
            remove = null;
        }
        else
        {
            remove = last.data;
            if(head.next==null)
                head = last = null;
            else
            {
                while(curr!=null)
                {
                    curr=curr.next;
                }
                remove=last.data;
                last = curr;
                curr.next=null;
            }
        }
        return remove;
    }

    //remove node from anywhere
    public void removeAnywhere(Student s) 
    {
        Node curr = head;
        if (curr != null && curr.getData().equals(s))
        {
            head = curr.next;
            curr = head; //update currNode when removing the first node
            // update last if the removed node is also the last node
            if (curr == last) 
            {
                last = null;
            }
            return;
        }

        Node prev = null;
        while (curr != null && !curr.getData().equals(s))
        {
            prev = curr;
            curr = curr.getNext();
        }

        if (curr == null)
        {
            return;
        }

        prev.next = curr.next;

        //update currNode if the removed node is the current node
        if (curr == curr) 
        {
            curr = prev.next;
        }

        //update last if the removed node is the last node
        if (curr == last) 
        {
            last = prev;
        }

        if (head==null) 
        {
            System.out.print("The list is now empty.");
        }
    }

    public Student getHead()
    {
        if(head==null)
            return null;
        else
        {
            current = head;
            return head.data;
        }
    }

    public Student getNext() {
        if (current != null && current != last) {
            current = current.next;
            if (current != null) {
                return current.data;
            } else {
                return null;
            }
        } else {
            current = null;  // Ensure current is reset after reaching the end
            return null;
        }
    }
    
      //return true if the list is empty
    public boolean isEmpty() 
    {
        return head == null;
    }


    public int getSize()
    {
        int size = 0;
        Node curr = head;


        while (curr != null) 
        {
            size++;
            curr = curr.next;
        }
        return size;
    }

        public void display()
    {
        Node curr = head;
        while (curr != null)
        {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}

