import java.util.LinkedList;

//the Queue class with a LinkedList field

public class Queue
{
    private LinkedList<Student> list = new LinkedList<>();
    
    //queue object has been initialized
    public Queue() 
    {
        list = new LinkedList();
    } //default constructor

    //insert element at the back of the queue object
    public void enqueue(Student student)    
    {
        list.addLast(student);
    } //method enqueue 

    //remove the front element from the queue object
    public Student dequeue()    
    {
        return list.removeFirst();
    } //method dequeue
    
    //determine the no of elements in the queue object
    public int size()    
    {
        return list.size();
    }// method size
    
    //check whether queue object has no element or otherwise
    public boolean isEmpty()
    {
        return list.isEmpty();
    }//method isEmpty
}

