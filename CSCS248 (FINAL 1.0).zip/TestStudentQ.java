import java.util.*;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
public class TestStudentQ {
    public static void main(String[] args) throws IOException {
        File file = new File("sukolList.txt");
        Scanner scan = new Scanner(file);

        Queue studentQ = new Queue();

        while (scan.hasNext()) {
            String indata = scan.nextLine();
            StringTokenizer st = new StringTokenizer(indata, ";");

            String stuName = st.nextToken();
            String stuId = st.nextToken();
            char college = st.nextToken().charAt(0);
            String courses = st.nextToken();
            int semester = Integer.parseInt(st.nextToken());
            String phoneNum = st.nextToken();
            String sport = st.nextToken();
            boolean statusWon = Boolean.parseBoolean(st.nextToken());
            double fee = Double.parseDouble(st.nextToken());

            Student s = new Student(stuName, stuId, college, courses, semester, phoneNum, sport, statusWon, fee);
            studentQ.enqueue(s);
        }

        Queue tempStu = new Queue();
        System.out.println("\t\t\t\t*************************SUKOL STUDENT LIST*************************");

        Student temp;
        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            System.out.println(temp.toString());
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        Scanner updateScan = new Scanner(System.in);
        System.out.println("\nEnter Student ID:  ");
        String studentIdToUpdate = updateScan.nextLine();
        boolean isFound = false;

        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            if (temp.getStuId().equalsIgnoreCase(studentIdToUpdate)) {
                isFound = true;
                break;
            }
            tempStu.enqueue(temp);
        }

        if (!isFound) {
            System.out.println("Warning: Student ID not found.");
        } else {
            System.out.println("Student ID found and processed.");
            while (!tempStu.isEmpty()) {
                temp = studentQ.dequeue();// Restore students back to the LinkedList
                if (temp.getStuId().equalsIgnoreCase(studentIdToUpdate)) {
                    // Ask if the user wants to update the phone number
                    System.out.println("\nDo you want to update phone number?[yes- Y | no - N] :  ");
                    char updatedPhoneNum = updateScan.next().charAt(0);
                    updateScan.nextLine();

                    if (updatedPhoneNum == 'Y' || updatedPhoneNum == 'y') {
                        // Get the new phone number from the user
                        System.out.println("\n\t\t\t\t\t========================UPDATE PHONE NUMBER========================");
                        System.out.println("\nEnter new phone number:  ");
                        String updated = updateScan.nextLine();
                        temp.setPhoneNum(updated);

                        System.out.println("\nPhone Number Updated Successfully!\n");
                        System.out.println("-----------------------------------------UPDATED-----------------------------------------");
                        System.out.println(temp.toString());
                    } else {
                        System.out.println("\nNo updates performed.\n");
                    }
                }
                tempStu.enqueue(temp);
            }
            
        }

         while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }
        Queue C = new Queue();
        Queue F = new Queue();
        Queue B = new Queue();
        Queue P = new Queue();
        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            if (temp.getSport().equalsIgnoreCase("CYCLING")) {
                C.enqueue(temp);
            } else if (temp.getSport().equalsIgnoreCase("FUTSAL")) {
                F.enqueue(temp);
            } else if (temp.getSport().equalsIgnoreCase("BADMINTON")) {
                B.enqueue(temp);
            } else if (temp.getSport().equalsIgnoreCase("PETANQUE")) {
                P.enqueue(temp);
            }
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF CYCLING STUDENTS========================");
        int CTotal = 0;
        while (!C.isEmpty()) {
            temp = C.dequeue();
            System.out.println(temp.toString());
            CTotal++;
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            C.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF FUTSAL STUDENTS========================");
        int FTotal = 0;
        while (!F.isEmpty()) {
            temp = F.dequeue();
            System.out.println(temp.toString());
            FTotal++;
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            F.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF BADMINTON STUDENTS========================");
        int BTotal = 0;
        while (!B.isEmpty()) {
            temp = B.dequeue();
            System.out.println(temp.toString());
            BTotal++;
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            B.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF PETANQUE STUDENTS========================");
        int PTotal = 0;
        while (!P.isEmpty()) {
            temp = P.dequeue();
            System.out.println(temp.toString());
            PTotal++;
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            P.enqueue(tempStu.dequeue());
        }

        System.out.println("\nNUMBER OF STUDENT PARTICIPATING IN CYCLING: " + CTotal);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN FUTSAL: " + FTotal);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN BADMINTON: " + BTotal);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN PETANQUE: " + PTotal);

        Queue KKA = new Queue();
        Queue KKB = new Queue();
        Queue KKC = new Queue();

        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            if (temp.getCollege() == 'A') {
                KKA.enqueue(temp);
            } else if (temp.getCollege() == 'B') {
                KKB.enqueue(temp);
            } else {
                KKC.enqueue(temp);
            }
        }

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKA STUDENTS========================");
        int KKACount = 0;
        while (!KKA.isEmpty()) {
            temp = KKA.dequeue();
            System.out.println(temp.toString());
            KKACount++;
            tempStu.enqueue(temp);
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKB STUDENTS========================");
        int KKBCount = 0;
        while (!KKB.isEmpty()) {
            temp = KKB.dequeue();
            System.out.println(temp.toString());
            KKBCount++;
            tempStu.enqueue(temp);
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKC STUDENTS========================");
        int KKCCount = 0;
        while (!KKC.isEmpty()) {
            temp = KKC.dequeue();
            System.out.println(temp.toString());
            KKCCount++;
            tempStu.enqueue(temp);
        }

        System.out.println("\nNUMBER OF STUDENT IN KKA: " + KKACount);
        System.out.println("NUMBER OF STUDENT IN KKB: " + KKBCount);
        System.out.println("NUMBER OF STUDENT IN KKC: " + KKCCount);

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        //calculate all of the fees
        double totalFee = 0.0;
        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            switch (temp.getSport().toUpperCase()) {
                case "CYCLING":
                    totalFee += temp.getFee() * 10.0;
                    break;
                case "FUTSAL":
                    totalFee += temp.getFee() * 7.0;
                    break;
                case "BADMINTON":
                    totalFee += temp.getFee() * 5.0;
                    break;
                case "PETANQUE":
                    totalFee += temp.getFee() * 8.0;
                    break;
            }
            tempStu.enqueue(temp);
        }

        System.out.println("\nTOTAL FEE COLLECTED: " + totalFee);

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        Queue noWinQ = new Queue();

        while (!studentQ.isEmpty()) {
            temp = studentQ.dequeue();
            if (!temp.getStatusWon()) {
                noWinQ.enqueue(temp);
            } else {
                tempStu.enqueue(temp);
            }
        }

        while (!tempStu.isEmpty()) {
            studentQ.enqueue(tempStu.dequeue());
        }

        System.out.println("\n\t\t\t\t\t===============LIST OF STUDENT THAT DO NOT WIN ANY COMPETITION================");

        while (!noWinQ.isEmpty()) {
            temp = noWinQ.dequeue();
            System.out.println(temp.toString());
            tempStu.enqueue(temp);
        }

        while (!tempStu.isEmpty()) {
            noWinQ.enqueue(tempStu.dequeue());
        }

    }
}
