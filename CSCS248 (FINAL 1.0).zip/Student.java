public class Student
{
    private String stuName;     //student's name
    private String stuId;       //20xxxxxx16
    private char college;       //[A]-KKA, [B]-KKB, [C],KKC
    private String courses;     //CDCS110, CDCS143, LG120, IM110, ACC110
    private int semester;       //Ex: 4
    private String phoneNum;    //01x-xxxxxxxx
    private String sport;       //Ex: CYCLING, FUTSAL, BADMINTON, PETANQUE
    private boolean statusWon;  //won sport competition: False / True
    private double fee;         //cycling RM10. futsal RM7, Badminton RM5, petanque RM8

    //normal contructor
    public Student(String stuName, String stuId, char college, String courses, int semester, String phoneNum, String sport, boolean statusWon, double fee)
    {
        this.stuName = stuName;
        this.stuId = stuId;
        this.college = college;
        this.courses = courses;
        this.semester = semester;
        this.phoneNum = phoneNum;
        this.sport = sport;
        this.statusWon = statusWon;
        this.fee = fee;
    }

    //getter 
    public String getStuName(){return stuName;}

    public String getStuId(){return stuId;}

    public char getCollege(){return college;}

    public String getCourses(){return courses;}

    public int getSemester(){return semester;}

    public String getPhoneNum(){return phoneNum;}

    public String getSport(){return sport;}

    public boolean getStatusWon(){return statusWon;}

    public double getFee(){return fee;}

    //setter
    public void setStuName(String newStuName){stuName = newStuName;}

    public void setStuId(String newStuId){stuId = newStuId;}

    public void setCollege(char newCollege){college = newCollege;}

    public void setCourses(String newCourses){courses = newCourses;}

    public void setSemester(int newSemester){semester = newSemester;}

    public void setPhoneNum(String newPhoneNum){phoneNum = newPhoneNum;}

    public void setSport(String newSport){sport = newSport;}

    public void setStatusWon(boolean newStatusWon){statusWon = newStatusWon;}

    public void setFee(double newFee){fee = newFee;}

    //display method
    public String toString()
    {
        return String.format("|%-36s|%-28s|%-15s|%-10s|%-5s|%-28s|%-13s|%-15s|%-13s|",
            stuName, stuId, college, courses, semester, phoneNum, sport, statusWon, fee);
    }

}
