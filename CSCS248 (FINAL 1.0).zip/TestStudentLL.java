import java.util.*;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
public class TestStudentLL
{
    public static void main(String []args)throws IOException
    {
        // Create a file object to read from "sukolList.txt"
        File file = new File ("sukolList.txt");
        // Scanner to read from the file
        Scanner scan = new Scanner (file);
        // LinkedList to store Student objects
        LinkedList studentLL = new LinkedList();

        //1.Store student information including student name, ID, college, courses, semester,phone number, sport, status won and fee and display.store student information 
        while(scan.hasNext())
        {
            String indata = scan.nextLine();
            StringTokenizer st = new StringTokenizer(indata,";");

            String stuName = st.nextToken();
            String stuId = st.nextToken();
            char college = st.nextToken().charAt(0);
            String courses = st.nextToken();
            int semester = Integer.parseInt(st.nextToken());
            String phoneNum = st.nextToken();
            String sport = st.nextToken();
            boolean statusWon = Boolean.parseBoolean(st.nextToken());
            double fee = Double.parseDouble(st.nextToken());

            Student s = new Student (stuName,stuId,college,courses,semester,phoneNum,sport,statusWon,fee);
            studentLL.addLast(s);
        }

        //display student information
        System.out.println("\t\t\t\t*************************SUKOL STUDENT LIST*************************");
        Student temp = studentLL.getHead();
        while(temp!=null)
        {
            System.out.println(temp.toString());
            temp = studentLL.getNext();
        } 

        Scanner updateScan = new Scanner(System.in);
        temp = studentLL.getHead();
        System.out.println("\nEnter Student ID: ");
        String studentIdToUpdate = updateScan.nextLine();
        boolean isFound = false;

        while (temp != null) {
            if (temp.getStuId().equalsIgnoreCase(studentIdToUpdate)) {
                isFound = true;
                break;
            }
            temp = studentLL.getNext();
        }

        if (!isFound) {
            System.out.println("Warning: Student ID not found.");
        } else {
            System.out.println("Student ID found and processed.");
            temp = studentLL.getHead(); // Reset temp to the head to find the student again
            while (temp != null) {
                if (temp.getStuId().equalsIgnoreCase(studentIdToUpdate)) {
                    // Ask if the user wants to update the phone number
                    System.out.println("\nDo you want to update phone number?[yes- Y | no - N] : ");
                    char updatedPhoneNum = updateScan.next().charAt(0);
                    updateScan.nextLine();

                    if (updatedPhoneNum == 'Y' || updatedPhoneNum == 'y') {
                        // Get the new phone number from the user
                        System.out.println("\n\t\t\t\t\t========================UPDATE PHONE NUMBER========================");
                        System.out.println("\nEnter new phone number: ");
                        String updated = updateScan.nextLine();

                        temp.setPhoneNum(updated);
                        System.out.println("\nPhone Number Updated Successfully!\n");
                        System.out.println("-----------------------------------------UPDATED-----------------------------------------");
                        System.out.println(temp.toString());
                    } else {
                        System.out.println("\n-> No updates performed.\n");
                    }
                }

                temp = studentLL.getNext();
            }
        }

        //3.Calculate and display the total number of students participating in each sport
        LinkedList C = new LinkedList();
        LinkedList F = new LinkedList();
        LinkedList B = new LinkedList();
        LinkedList P =  new LinkedList();
        temp = studentLL.getHead();
        int total = 0;
        while(temp!=null)
        {
            // Categorize students based on the sport they participate in
            if(temp.getSport().equalsIgnoreCase("CYCLING"))
            {
                C.addLast(temp);
            }
            else if (temp.getSport().equalsIgnoreCase("FUTSAL"))
            {
                F.addLast(temp);
            }
            else if (temp.getSport().equalsIgnoreCase("BADMINTON"))
            {
                B.addLast(temp);
            }
            else if (temp.getSport().equalsIgnoreCase("PETANQUE"))
            {
                P.addLast(temp);
            }
            temp = studentLL.getNext();
        }

        // Display students participating in each sport
        System.out.println("\n\t\t\t\t\t========================LIST OF CYCLING STUDENTS========================");
        int CTotal = 0;
        temp = C.getHead();
        while (temp != null) 
        {
            System.out.println(temp.toString());
            CTotal++;
            temp = C.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF FUTSAL STUDENTS========================");
        int FTotal = 0;
        temp = F.getHead();
        while (temp != null)
        {
            System.out.println(temp.toString());
            FTotal++;
            temp = F.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF BADMINTON STUDENTS========================");
        int BTotal = 0;
        temp = B.getHead();
        while (temp != null) 
        {
            System.out.println(temp.toString());
            BTotal++;
            temp = B.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF PETANQUE STUDENTS========================");
        int PTotal = 0;
        temp = P.getHead();
        while (temp != null) 
        {
            System.out.println(temp.toString());
            PTotal++;
            temp = P.getNext();
        }

        // Display total number of students participating in each sport
        System.out.println("\nNUMBER OF STUDENT PARTICIPATING IN CYCLING: "+ CTotal++);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN FUTSAL: "+ FTotal++);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN BADMINTON: "+ BTotal++);
        System.out.println("NUMBER OF STUDENT PARTICIPATING IN PETANQUE: " + PTotal++);

        //Count and display the number of students from each college.
        LinkedList KKA = new LinkedList();
        LinkedList KKB = new LinkedList();
        LinkedList KKC = new LinkedList();
        temp = studentLL.getHead();
        int count = 0;
        while(temp!=null)
        {
            // Categorize students based on their college
            if(temp.getCollege() == 'A')
            {
                KKA.addLast(temp);
            }
            else if (temp.getCollege() == 'B')
            {
                KKB.addLast(temp);
            }
            else if (temp.getCollege() == 'C')
            {
                KKC.addLast(temp);
            }
            temp = studentLL.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKA STUDENTS========================");
        int KKACount = 0;
        temp = KKA.getHead();
        while (temp != null) 
        {
            System.out.println(temp.toString());
            KKACount++;
            temp = KKA.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKB STUDENTS========================");
        int KKBCount = 0;
        temp = KKB.getHead();
        while (temp != null)
        {
            System.out.println(temp.toString());
            KKBCount++;
            temp = KKB.getNext();
        }

        System.out.println("\n\t\t\t\t\t========================LIST OF KKC STUDENTS========================");
        int KKCCount = 0;
        temp = KKC.getHead();
        while (temp != null) 
        {
            System.out.println(temp.toString());
            KKCCount++;
            temp = KKC.getNext();
        }

        System.out.println("\nNUMBER OF STUDENT IN KKA: " + KKACount);
        System.out.println("NUMBER OF STUDENT IN KKB: " + KKBCount);
        System.out.println("NUMBER OF STUDENT IN KKC: " + KKCCount);

        double totalFee = 0.0;
        temp = studentLL.getHead();
        while (temp != null) {
            switch (temp.getSport().toUpperCase()) {
                case "CYCLING":
                    totalFee += temp.getFee() * 10.0;
                    break;
                case "FUTSAL":
                    totalFee += temp.getFee() * 7.0;
                    break;
                case "BADMINTON":
                    totalFee += temp.getFee() * 5.0;
                    break;
                case "PETANQUE":
                    totalFee += temp.getFee() * 8.0;
                    break;
            }
            temp = studentLL.getNext();
        }

        System.out.println("\nTOTAL FEE COLLECTED: " + totalFee);

        //5.Remove student data that do not win any competition
        LinkedList noWinLL= new LinkedList();
        temp = studentLL.getHead();

        while (temp != null) {
            if (!temp.getStatusWon()) {
                noWinLL.addFirst(temp);
            }
            temp = studentLL.getNext();
        }

        temp = noWinLL.getHead();
        while (temp != null) {
            studentLL.removeAnywhere(temp);
            temp = noWinLL.getNext();
        }

        // Display students that did not win any competition
        System.out.println("\n\t\t\t\t\t===============LIST OF STUDENT THAT DO NOT WIN ANY COMPETITION================");
        temp = noWinLL.getHead();
        while (temp != null) {
            System.out.println(temp.toString());
            temp = noWinLL.getNext();
        }

    }
}
